'''Operador ternario 02'''

import random
numero_aleatorio = random.randint(0,10)
print(numero_aleatorio)

numero2 = int(input("Introduce el numero, a ver si lo adivinas:"))

mensaje = "has acertado" if numero2 == numero_aleatorio else "pueba otra vez"

print(mensaje)
