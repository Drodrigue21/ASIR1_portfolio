'''Práctica características de las variables'''

# nombre curso = "Módulo Python" # Error por espacio en blanco
nombre_curso = "ASIR1"
# Solucionado aunque cree que es una constante y debería estar en mayúsculas
print(nombre_curso)

# 7nombre_alumno = "Pedro" # Error por empezar con un número
nombre_alumno1 = "Pedro"
print(nombre_alumno1)

tareasParaHacer = "Hacer la cama"
# camelcase
print(tareasParaHacer)

NotaFinal = 10
# PascalCase
print(NotaFinal)

modulos_para_estudiar = "Python"
# snake_case
print(modulos_para_estudiar)

DIA_SEMANA = "Lunes"
# screaming SNAKE_CASE cree que es una constante
print(DIA_SEMANA)

# segundo-apellido = "López" #Kebab case en python no vale

print(nombre_curso, nombre_alumno1, tareasParaHacer,
      NotaFinal, modulos_para_estudiar, DIA_SEMANA)

nalumnos = 24  # Entero
medianota = 8.9  # Decimal o Float
curso_comenzado = True  # Booleano

print(nalumnos, medianota, curso_comenzado)
