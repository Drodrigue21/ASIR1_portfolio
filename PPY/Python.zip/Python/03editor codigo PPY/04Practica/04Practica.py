print("¡Hola Mundo!") ##Función que imprime en el terminal lo que nosotros indiquemos, ahora lo que estamos es imprimiendo un texto. Usa ( ) y lo necesita para poder ejecutarse
#Para ejecutar el Terminal. View/Terminal o CTRL+ñ o Play de la parte superior derecha
print("Bienvenidos al curso de python" *4)
print()