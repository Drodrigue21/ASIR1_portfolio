'''Secuencias escape'''

pais1 = "Reino Unido"
print(pais1)

isla = 'Gran "Canaria"'
print(isla)

ciudad1 = "Ciudad \"Real\""
print(ciudad1)

ciudad2 = "Ciudad 'Rodrigo'"
print(ciudad2)

texto1 = "# práctica 1"
print(texto1)

texto2 = 'práctica' + '#' + '01'
print(texto2)

ruta1="C:\Program Files"
print(ruta1)

ruta2="C:\Users\ASIR1-21\Desktop"
print(ruta2)

galaxia = "Via \\lactea\\"
print(galaxia)

constelacion = "Osa \nMayor"
print(constelacion)

nombre_completo = "Pedro\nGuerreron\nLopez"
print(nombre_completo)