'''Fortamto de variables tipo string'''
nombre = "Pedro"
Apellido1 = "Guerrero"
Apellido2 = "Lopez"

nombre_completo = nombre+Apellido1+Apellido2
print(nombre_completo)

nombre_completo = nombre+" "+Apellido1+" "+Apellido2
print(nombre_completo)

nivel = "Fuendamentos de"
tipo = "Programacion"
lenguaje = "Python"
nombre_modulo = f"{nivel} {tipo} {lenguaje}"
print(nombre_modulo)

modulo = "Gestion de Bases de Datos"
dia1 = 1
dia2 = 2
dia3 = 3
datos_modulo = f"{modulo[0]}{modulo[11]}{modulo[20]} {"="} {dia1+dia2+dia3} {"horas por semana"}"
print(datos_modulo)