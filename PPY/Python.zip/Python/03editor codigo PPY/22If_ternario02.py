'''Operador ternario 02'''

numero1 = 8
numero2 = int(input("Introduce el numero, a ver si lo adivinas:"))

mensaje = "has acertado" if numero2 == numero1 else "pueba otra vez"

print(mensaje)
