'''Modulo math nativo'''

print("Parte entera impar")

precio = 1.95
print("precio")
print("El precio redondeado es:", round(precio))

precio = 1.35
print("precio")
print("El precio redondeado es:", round(precio))

precio = 1.5
print("precio")
print("El precio redondeado es:", round(precio))

print("Parte entera es par")

precio = 14.95
print(precio)
print("El precio redondeado es:", round(precio))

precio = 14.35
print(precio)
print("El precio redondeado es:", round(precio))

precio = 14.5
print(precio)
print("El precio redondeado es:", round(precio))

print("El precio redondeado es:", round(precio))

print(round(3.14159))


print(round(3.14159, 1))
print(round(3.14159, 2))
print(round(3.14159, 3))
print(round(3.14159, 4))
print(round(3.14159, 5))

print(round(3.14159, -1))

print(round(4458.1242, -1))

print(round(1876.985, -1))
print(round(1876.985, -2))
print(round(1876.985, -3))

print(round(1876.985, 2))
print(round(1876.985, 1))

print(abs(-98))
print(abs(104))
print(abs(+104))

a = -7
print(a)
a = abs (a)
print(a)