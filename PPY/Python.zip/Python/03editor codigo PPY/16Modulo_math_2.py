'''Importando el modulo math'''

import math

print("Probando math.ceil()")
print(math.ceil(3.43))
print(math.ceil(-3.43))

a = 5
b = 2
print(a/b)
print(math.ceil(a/b))
print(round(a/b))


print("probando math.floor()")
print(math.floor(3.99))
print(math.floor(-3.99))

print(math.isnan(56.24))
#print(math.isnan("56.24"))

print(math.pow(2, 8))

print(math.sqrt(144))