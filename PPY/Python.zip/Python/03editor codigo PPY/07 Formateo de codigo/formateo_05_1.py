'''Formato codigo'''
dia_semana="Lunes"
mes_año="Marzo"
print('Hola')
sumando1 = 5
sumando2 = 7
nombre = "Dani"
print(nombre)