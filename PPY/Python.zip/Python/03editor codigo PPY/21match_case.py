'''match case estructura'''

while True:
    try:
        nota = input("Introduce la nota:")
        nota = float(nota)
        break
    except ValueError:
        print("Introduce un valor numerico, por favor")

######################
print(nota)
mensaje = "nada"
match nota:
    case n if n > 10:
        mensaje = "Nota fuera de rango"
    case n if n == 10:
        mensaje = "MH"
    case n if n >= 9:
        mensaje = "Sobresaliente"
    case n if n >= 7:
        mensaje = "Notable"
    case n if n >= 6:
        mensaje = "Bien"
    case n if n >= 5:
        mensaje = "Suficiente"
    case n if n >= 0:
        mensaje = "Suspenso"
    case n if n < 0:
        mensaje = "No es una nota"
print(mensaje)
