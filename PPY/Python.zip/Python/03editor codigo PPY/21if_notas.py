'''If notas'''

nota1 = float(input("Intoduce notas:"))
nota1=int(nota1)
print(nota1)

mensaje = "nada"
if nota1 <= 4:
    mensaje = "Suspenso"
elif nota1 < 6:
    mensaje = "Suficiente"
elif nota1 < 7:
    mensaje = "Bien"
elif nota1 < 9:
    mensaje = "Notable"
elif nota1 < 10:
    mensaje = "Sobresaliente"
elif nota1 == 10:
    mensaje = "Matricula"
elif nota1 > 10:
    mensaje = "Nota fuera de rango"
else:
    mensaje = "No es una nota"
print(mensaje)
