'''Practica 07'''
num = int(input("Introduce un número:"))

# Para controlar el error de meter un caracter
while True:
    try:
        num = int(input("Introduce un número:"))
        break
    except ValueError:
        print("Introduce un valor numerico, por favor")

if num % 2 == 0:
    print("El", num, "es par")
else:
    print("El", num, "es impar")

mensaje = f"El {num} es par" if num % 2 == 0 else f"El {num} es impar"
print(mensaje)
