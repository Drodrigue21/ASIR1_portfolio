'''Practica 06'''
while True:
    try:
        a = int(input("Introduce un numero a:"))
        break
    except ValueError:
        print("Introduce un valor numerico a, por favor")
while True:
    try:
        b = int(input("Introduce un numero b:"))
        break
    except ValueError:
        print("Introduce un valor numerico b, por favor")

if a > b:
    print("El mayor es:", a)
else:
    if a == b:
        print("Son iguales")
    else:
        print("El mayor es:",b)

# Mensaje parametrizado
if a > b:
    print("De entre", a, "y", b, "el mayor es:", a)
else:
    if a == b:
        print(a, "y", b, "son iguales")
    else:
        print("De entre", a, "y", b, "el mayor es:", b)
