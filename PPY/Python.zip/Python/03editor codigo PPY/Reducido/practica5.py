'''Practica 05'''
while True:
    try:
        numero = int(input("Introduce un número:"))
        break
    except ValueError:
        print("Introduce un valor numerico, por favor")

if numero > 0:
    print("Es positivo")
else:
    if numero == 0:
        print("Es cero")
    else:
        print("Es negativo")




# Con mensaje parametrizado en variable
if numero > 0:
    mensaje1 = "es positivo"
else:
    if numero == 0:
        mensaje1 = "es cero"
    else:
        mensaje1 = "es negativo"

mensaje2 = f"El numero {numero}, {mensaje1}: Fin del programa"

print(mensaje2)