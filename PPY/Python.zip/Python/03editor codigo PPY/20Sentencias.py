'''Sentencias if o condicionales'''

edad = 20
print(edad)
if edad >= 18:
    print("puedes ver la pelicula")



print("FIN 1")

########################################

edad = 14
print(edad)
if edad >= 18:
    print("puedes ver la pelicula 2")



print("FIN 2")

####################################

edad = 14
print(edad)
if edad >= 18:
    print("puedes ver la pelicula 3")
else:
    print("No puedes entrar 3")

print("FIN 3")

################################

edad = 20
print(edad)
if edad >= 18:
    print("puedes ver la pelicula 4")
else:
    print("No puedes entrar 4")
    print("Aqui no la puedes ver 4")

print("FIN 4")

################################

edad = 14
print(edad)
if edad >= 18:
    print("puedes ver la pelicula 5")
else:
    print("No puedes entrar 5")
    print("Aqui no la puedes ver 5")

print("FIN 5")

##############################

edad = 20
print(edad)
if edad >= 18:
    print("puedes ver la pelicula 6")
else:
    print("No puedes entrar 6")

print("Aqui no la puedes ver 6") #Error en la sangria

print("FIN 6")

######################################

edad = 20
print(edad)
if edad > 65:
    print("Puedes ver la pelicula 7 y tienes descuento")
else:
    if edad >= 18:
        print("Puedes ver la pelicula 7, no tienes descuento")
    else:
        print("No puedes entrar 7")
        print("Aqui no la puedes ver 7")

print("FIN 7")

######################################

edad = 14
print(edad)
if edad > 65:
    print("Puedes ver la pelicula 8 y tienes descuento")
else:
    if edad >= 18:
        print("Puedes ver la pelicula 8, no tienes descuento")
    else:
        print("No puedes entrar 8")
        print("Aqui no la puedes ver 8")

print("FIN 8")

#########################################

edad = 67
print(edad)
if edad > 65:
    print("Puedes ver la pelicula 9 y tienes descuento")
else:
    if edad >= 18:
        print("Puedes ver la pelicula 9, no tienes descuento")
    else:
        print("No puedes entrar 9")
        print("Aqui no la puedes ver 9")

print("FIN 9")

##############################################

edad = 67
print(edad)
if edad > 65:
    print("Puedes ver la pelicula 10 y tienes descuento")
else:
    if edad >= 18:
        print("Puedes ver la pelicula 10, no tienes descuento")
    else:
        print("No puedes entrar 10")
        print("Aqui no la puedes ver 10")

print("FIN 9")

################################################

edad = 67
print(edad)
if edad >= 70:
    print("Puedes ver la pelicula 11 gratis")
else:
    if edad > 65:
        print("Puedes ver la pelicula 11 y tienes descuento")
    else:
        if edad >= 18:
            print("Puedes ver la pelicula 11, no tienes descuento")
        else:
            print("No puedes entrar 11")
            print("Aqui no la puedes ver 11")

print("FIN 11")

