'''Calculadora básica'''

a1 = input("Introduce el primer numero:")
a2 = input("Introduce el segundo numero:")
a = a1+a2
print(a)

a1 = input("Introduce el primer numero:")
a1=int(a1)

a2 = int(input("Introduce el segundo número"))

a = a1+a2
print(a)

a1 = int(input("Introduce el primer número"))
a2 = int(input("Introduce el segundo número"))

suma = a1+a2
resta = a1-a2
multiplicacion = a1*a2
division = a1/a2

mensaje1 = f"Con los numeros introducidos, {a1}, {a2}, la suma es {suma}, la resta es {resta}, la multiplicacion es{multiplicacion}, la division es {division}"

print(mensaje1)

# print(suma)
# print(resta)
# print(multiplicacion)
# print(division)

mensaje2 = f"""
Con los numeros introducidos, {a1} y {a2}, 
la suma es {suma}, 
la resta es {resta}, 
la multiplicacion es{multiplicacion}, 
la division es {division}
"""
print(mensaje2)