'''Métodos de string'''

asignatura = "Física Cuántica"
print(asignatura. upper())
print(asignatura. lower())

ciencia = "física del estado sólido"

print(ciencia.capitalize())

# Esto en css es capitalize.
print(ciencia.title())

ubicacion1 = " lagos de Covadonga asturias "
print(ubicacion1.upper())
print(ubicacion1.lower())
print(ubicacion1.capitalize())
print(ubicacion1.title())

ubicacion2 = " lagos de Covadonga asturias "
print(ubicacion2.strip())
print(ubicacion2.strip().capitalize())

ubicacion3 = " Sierra de Gredos "
print(ubicacion3.lstrip())
print(ubicacion3.rstrip())
print(ubicacion3.lstrip()+"Almanzor")
print(ubicacion3.rstrip()+"Almanzor")

print(ubicacion3.find("S"))
print(ubicacion3.find("s"))
print(ubicacion3.find("Sierra"))
print(ubicacion3.find("sierra"))
print(ubicacion3.find("Gr"))
print(ubicacion3.lstrip().find("S"))
print(ubicacion3.find("Fisica"))


print(ubicacion3.replace("gredos","Guadarrama"))
print(ubicacion3.replace("Gredos","Guadarrama"))
print(ubicacion3)
ubicacion3 = ubicacion3.replace("Gredos", "Guadarrama")
print(ubicacion3)
print(ubicacion3)
print(ubicacion3)

ubicacion3_guion= ubicacion3.strip().replace(" ","_")
print(ubicacion3_guion)

ubicacion3_sin= ubicacion3.strip().replace(" ","")
print(ubicacion3_sin)

A = "Gredos"
B = "Guadarrama"
print(ubicacion3.replace(A, B))
print(ubicacion3)

print("de" in ubicacion3)
print("De" in ubicacion3)

A = "de"
print(A in ubicacion3)

print("Cuantica" not in ubicacion3)
print("de" not in ubicacion3)