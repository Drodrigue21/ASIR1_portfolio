'''Numeros'''

edad = "18"
print(edad)
nota = 8.9
print(nota)

complejo = 5+3j
print(complejo)

sumando1=7
sumando2=3
suma=sumando1+sumando2
print("La suma de", sumando1, "+", sumando2, "es:", suma )

restando1=70
restando2=30
resta=restando1-restando2
print("La resta de", restando1, "-", restando2, "es:", resta )

factor1=10
factor2=6
multiplicacion=factor1*factor2
print("La resta de", factor1, "X", factor2, "es:", multiplicacion )

divisor1=80
divisor2=3
Division=divisor1/divisor2
print("La resta de", divisor1, "/", divisor2, "es:", Division )

print("contador, aumento de 1")
contador = 8
print(contador)
contador = contador+1
print(contador)

print("Forma corta de operacion, del contador anterior")

contador = 8
print(contador)
contador += 8
print(contador)

print("Forma corta con suma")
a = 14
print(a)
a += 2
print(a)

print("Forma corta con resta")
a = 14
print(a)
a -= 2
print(a)

print("Forma corta con multiplicacion")
a = 14
print(a)
a *= 2
print(a)

print("Forma corta con division")
a = 14
print(a)
a /= 2
print(a)

print("Forma corta con potencia")
a = 14
print(a)
a **= 2
print(a)

print("Forma corta con división entera")
a = 25
a //= 2
print(a)

print("Forma corta con módulo")
# módulo
a = 25
a %= 2
print(a)